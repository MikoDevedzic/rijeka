# Rijeka Model Validation Package
**Version:** v0.4.2 | Sprint 6B  
**Date:** 2026-04-10  
**Author:** Miko Devedzic / Rijeka  
**License:** MIT

---

## Overview

Self-contained Python replication of the Rijeka IRS pricing and XVA engine.  
Runs independently — no connection to Rijeka backend required.  
Reproduces every test result from the Rijeka Model Validation Report.

---

## Files

```
rijeka_validation/
  ois_bootstrap.py     OIS curve bootstrap (USD SOFR, EUR ESTR, GBP SONIA)
  irs_pricer.py        IRS full revaluation + Greeks (NPV, IR01, IR01_DISC, Gamma, Theta)
  xva_engine.py        HW1F calibration + Monte Carlo XVA waterfall
  run_validation.py    Full test suite — single entry point
  requirements.txt     numpy, scipy, python-dateutil
  README.md            This file
```

---

## Quick Start

```bash
pip install -r requirements.txt
python run_validation.py
```

Expected output: **30/30 PASSED**

---

## Individual Modules

```bash
# OIS bootstrap — print zero curve
python ois_bootstrap.py

# IRS pricer — par swap validation
python irs_pricer.py

# XVA engine — full waterfall
python xva_engine.py
```

---

## Test Coverage

### 1. OIS Bootstrap (5 tests)
- DF(0) = 1.0
- Discount factors monotone decreasing
- All DFs positive
- 5Y zero rate in [3%, 5%]
- DF(30Y) < DF(5Y)

### 2. IRS Pricing (12 tests)
- Par swap NPV ≈ $0 (Bloomberg SWPM cross-check: 5Y $10M @ 3.665% → $0.02)
- Off-market sign: PAY FIXED above par → NPV < $0
- Off-market sign: PAY FIXED below par → NPV > $0
- Direction symmetry: PAY + RECEIVE NPV = $0
- IR01 sign: PAY FIXED → positive IR01
- IR01 sign: RECEIVE FIXED → negative IR01
- IR01 symmetry: |PAY IR01 + RECEIVE IR01| < $1
- Notional linearity: 2× notional → 2× NPV
- Notional linearity: 2× notional → 2× IR01
- IR01_DISC < IR01 (discount-only < full curve sensitivity)
- Par rate solver converges to 3.665% ±1bp

### 3. XVA Engine (13 tests)
- CVA < 0 (cost to us)
- DVA > 0 (benefit to us)
- FVA < 0 (funding cost)
- KVA < 0 (capital cost)
- MVA < 0 (margin cost)
- Zero CDS spreads → CVA = $0
- Zero CDS spreads → DVA = $0
- LGD = 0 → CVA = $0
- LGD = 0 → DVA = $0
- Direction flip: RECEIVE FIXED CVA/DVA signs preserved
- Maturity sensitivity: 2Y CVA ≈ 5–25% of 5Y CVA
- EE peaks between 1Y and 4Y
- EE ≥ 0 everywhere, ENE ≤ 0 everywhere
- All-in rate < par rate for PAY FIXED

### 4. Greeks (5 tests)
- Gamma near zero for vanilla IRS
- Theta non-zero
- IR01 magnitude: $3,000–$6,000 for 5Y $10M
- IR01_DISC < IR01
- Central difference IR01 ≈ bump IR01

---

## Model Notes

### OIS Bootstrap
- Dense annual grid with frozen T+2 spot pillar
- Sequential Newton solver per tenor
- Log-linear DF interpolation
- Validated: USD SOFR 5Y $10M at 3.665% → NPV = $0.02 (Bloomberg SWPM)

### IRS Pricer
- Full revaluation (not approximation)
- Fixed leg: ACT/360, annual payment
- Float leg: OIS compounding, forward rate from forecast curve
- Greeks: finite difference bump-and-reprice
- IR01: parallel shift of all curves +1bp
- IR01_DISC: discount curve only +1bp, forecast held flat
- Gamma: NPV(+1bp) + NPV(-1bp) - 2×NPV(0)
- Theta: NPV(T+1) - NPV(T), curves unchanged

### HW1F Calibration
- Parameters: a=0.0121, σ=29.99bp, RMSE=0.08bp
- Basket: 6 ATM swaptions, 5Y tenor column (1Y×5Y to 10Y×5Y)
- Optimizer: L-BFGS-B
- Formula: Andersen-Piterbarg simplified swaption vol

### CVA Formula (corrected Sprint 6B)
```
h(t)  = spread_bp(t) / 10000         # hazard rate from term structure
Q(t)  = exp(-h(t) × t)               # survival probability
CVA   = -LGD × Σ EE(t) × (Q(t-1) - Q(t)) × DF(t) × WWR
```
Note: LGD appears only in the sum. Prior implementation had LGD in the 
exponent (h/LGD), which overstated CVA by factor 1/LGD = 2.5× for LGD=40%.

---

## Copyright
© 2026 Miko Devedzic / Rijeka. MIT License.
