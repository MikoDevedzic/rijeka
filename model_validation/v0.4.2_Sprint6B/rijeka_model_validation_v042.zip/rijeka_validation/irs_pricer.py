"""
Rijeka Model Validation Package
IRS Pricer — full revaluation + Greeks
Sign: PAY FIXED below par -> NPV>0, above par -> NPV<0
IR01: PAY FIXED -> positive (rates up = gain on float)
"""

import math
from datetime import date, timedelta
from ois_bootstrap import OISBootstrap, dcf_act360, dcf_act365f, add_tenor


def generate_schedule(eff_date, mat_date, freq='ANNUAL'):
    from dateutil.relativedelta import relativedelta
    freq_map = {'MONTHLY': relativedelta(months=1), 'QUARTERLY': relativedelta(months=3),
                'SEMI_ANNUAL': relativedelta(months=6), 'ANNUAL': relativedelta(years=1)}
    delta = freq_map.get(freq, relativedelta(years=1))
    d0 = date.fromisoformat(eff_date)
    dm = date.fromisoformat(mat_date)
    sched, ds = [], d0
    while True:
        de = ds + delta
        if de >= dm: de = dm
        dp = de
        while dp.weekday() >= 5: dp += timedelta(days=1)
        sched.append((ds.strftime('%Y-%m-%d'), de.strftime('%Y-%m-%d'), dp.strftime('%Y-%m-%d')))
        if de >= dm: break
        ds = de
    return sched


def bump_curve(curve, bump):
    b = OISBootstrap(curve.val_date, curve.ccy)
    b.pillars = [(t, df if t<=0 else math.exp(-(-math.log(df)/t + bump)*t)) for t,df in curve.pillars]
    return b


def _swap_npv(disc, fcast, notional, eff, mat, rate, pay_fixed, dc, freq, spread, vd):
    sign = 1.0 if pay_fixed else -1.0
    sched = generate_schedule(eff, mat, freq)
    npv = 0.0
    for d0, d1, dp in sched:
        frac = dcf_act360(d0, d1) if dc != 'ACT/365F' else dcf_act365f(d0, d1)
        t0 = dcf_act365f(vd, d0); t1 = dcf_act365f(vd, d1); tp = dcf_act365f(vd, dp)
        if tp < 0: continue
        df_p = disc.df(tp)
        df0  = fcast.df(max(0.0, t0)); df1 = fcast.df(t1)
        fwd  = (df0/df1 - 1.0)/frac if (frac>0 and df1>0 and df0>0) else 0.0
        npv += -sign * notional * rate * frac * df_p          # fixed leg
        npv +=  sign * notional * (fwd+spread) * frac * df_p  # float leg
    return npv


def _full_price(disc, fcast, notional, eff, mat, rate, pay_fixed, dc, freq, spread, vd):
    sign = 1.0 if pay_fixed else -1.0
    sched = generate_schedule(eff, mat, freq)
    fixed_pv = float_pv = 0.0
    fixed_cf = []; float_cf = []
    for d0, d1, dp in sched:
        frac = dcf_act360(d0, d1) if dc != 'ACT/365F' else dcf_act365f(d0, d1)
        t0 = dcf_act365f(vd, d0); t1 = dcf_act365f(vd, d1); tp = dcf_act365f(vd, dp)
        if tp < 0: continue
        df_p = disc.df(tp)
        df0  = fcast.df(max(0.0, t0)); df1 = fcast.df(t1)
        fwd  = (df0/df1 - 1.0)/frac if (frac>0 and df1>0 and df0>0) else 0.0
        fc  = -sign * notional * rate * frac * df_p
        flt =  sign * notional * (fwd+spread) * frac * df_p
        fixed_pv += fc; float_pv += flt
        fixed_cf.append({'period_start':d0,'period_end':d1,'payment_date':dp,'dcf':frac,'rate':rate,'df':df_p,'amount':notional*rate*frac,'pv':fc})
        float_cf.append({'period_start':d0,'period_end':d1,'payment_date':dp,'dcf':frac,'rate':fwd,'df':df_p,'amount':notional*(fwd+spread)*frac,'pv':flt})
    return {'npv':fixed_pv+float_pv,'fixed_pv':fixed_pv,'float_pv':float_pv,'fixed_cf':fixed_cf,'float_cf':float_cf}


class IRSPricer:
    def __init__(self, disc_curve, fcast_curve=None, notional=10_000_000,
                 eff_date=None, mat_date=None, fixed_rate=0.03665, direction='PAY',
                 day_count_fixed='ACT/360', day_count_float='ACT/360',
                 pay_freq_fixed='ANNUAL', pay_freq_float='ANNUAL',
                 spread=0.0, leverage=1.0, val_date=None):
        self.disc = disc_curve; self.fcast = fcast_curve or disc_curve
        self.n = notional; self.vd = val_date or disc_curve.val_date
        self.rate = fixed_rate; self.pay = direction.upper()=='PAY'
        self.spread = spread; self.dc = day_count_fixed; self.freq = pay_freq_fixed
        if eff_date is None:
            v = date.fromisoformat(self.vd); e = v+timedelta(days=2)
            while e.weekday()>=5: e+=timedelta(days=1)
            eff_date = e.strftime('%Y-%m-%d')
        if mat_date is None: mat_date = add_tenor(eff_date,'5Y')
        self.eff = eff_date; self.mat = mat_date

    def _npv(self, disc=None, fcast=None, vd=None):
        return _swap_npv(disc or self.disc, fcast or self.fcast, self.n,
                         self.eff, self.mat, self.rate, self.pay,
                         self.dc, self.freq, self.spread, vd or self.vd)

    def price(self):
        base = _full_price(self.disc, self.fcast, self.n, self.eff, self.mat,
                           self.rate, self.pay, self.dc, self.freq, self.spread, self.vd)
        npv = base['npv']
        bd = bump_curve(self.disc, 1e-4); bf = bump_curve(self.fcast, 1e-4)
        bd2= bump_curve(self.disc,-1e-4); bf2= bump_curve(self.fcast,-1e-4)
        ir01      = self._npv(bd, bf)  - npv
        ir01_disc = self._npv(bd, self.fcast) - npv
        gamma     = self._npv(bd, bf) + self._npv(bd2, bf2) - 2*npv
        tomorrow  = (date.fromisoformat(self.vd)+timedelta(days=1)).strftime('%Y-%m-%d')
        theta     = self._npv(vd=tomorrow) - npv
        return {**base, 'ir01':ir01, 'ir01_disc':ir01_disc, 'gamma':gamma, 'theta':theta,
                'notional':self.n, 'fixed_rate':self.rate,
                'direction':'PAY' if self.pay else 'RECEIVE',
                'tenor_y':dcf_act365f(self.eff,self.mat), 'val_date':self.vd,
                'eff_date':self.eff, 'mat_date':self.mat}

    def par_rate(self, tol=1e-8):
        lo, hi = 0.0001, 0.25
        for _ in range(100):
            mid = (lo+hi)/2
            npv = _swap_npv(self.disc, self.fcast, self.n, self.eff, self.mat,
                            mid, self.pay, self.dc, self.freq, self.spread, self.vd)
            if (self.pay and npv>0) or (not self.pay and npv<0): lo=mid
            else: hi=mid
            if hi-lo < tol: break
        return (lo+hi)/2


if __name__ == '__main__':
    from ois_bootstrap import build_sofr_curve
    curve = build_sofr_curve()
    p = IRSPricer(curve, notional=10_000_000, direction='PAY',
                  eff_date='2026-04-14', mat_date='2031-04-14', val_date='2026-04-10')
    par = p.par_rate()
    print(f"Par rate: {par*100:.4f}%")
    p2 = IRSPricer(curve, notional=10_000_000, fixed_rate=par, direction='PAY',
                   eff_date='2026-04-14', mat_date='2031-04-14', val_date='2026-04-10')
    r = p2.price()
    print(f"NPV at par: ${r['npv']:,.2f} | IR01: ${r['ir01']:,.2f} | Theta: ${r['theta']:,.2f}")
