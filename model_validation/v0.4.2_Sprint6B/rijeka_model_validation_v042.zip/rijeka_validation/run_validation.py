"""
Rijeka Model Validation Package
================================
Full test suite — single entry point.
Usage: python run_validation.py
Requirements: pip install numpy scipy python-dateutil
"""

import math, sys
from datetime import datetime

RESULTS = []

def test(name, condition, got, expected):
    status = "PASS" if condition else "FAIL"
    RESULTS.append({'name':name,'status':status,'got':got,'expected':expected})
    print(f"  {'✓' if condition else '✗'}  {name}")
    if not condition:
        print(f"       Expected: {expected}")
        print(f"       Got:      {got}")

def section(title):
    print(f"\n{'─'*60}\n  {title}\n{'─'*60}")

# ── 1. OIS Bootstrap ──────────────────────────────────────────────────────────

def test_bootstrap(curve):
    section("1. OIS BOOTSTRAP")
    import math
    test("DF(0) = 1.0", abs(curve.df(0.0)-1.0)<1e-8, f"{curve.df(0.0):.8f}", "1.0")
    dfs = [curve.df(t) for t in [1,2,3,5,7,10]]
    test("DF monotone decreasing", all(dfs[i]>dfs[i+1] for i in range(len(dfs)-1)), dfs, "monotone")
    test("All DFs positive", all(d>0 for d in dfs), min(dfs), "> 0")
    zr = -math.log(curve.df(5))/5
    test("5Y zero rate in [3%,5%]", 0.03<=zr<=0.05, f"{zr*100:.4f}%", "3%-5%")
    test("DF(30Y) < DF(5Y)", curve.df(30)<curve.df(5), f"DF30={curve.df(30):.4f}", "< DF5")

# ── 2. IRS Pricing ────────────────────────────────────────────────────────────

def test_irs(curve):
    from irs_pricer import IRSPricer
    section("2. IRS PRICING")

    EFF = '2026-04-14'; MAT = '2031-04-14'; VD = '2026-04-10'

    # Compute par rate from curve
    p0 = IRSPricer(curve, notional=10_000_000, direction='PAY',
                   eff_date=EFF, mat_date=MAT, val_date=VD)
    par = p0.par_rate()

    # 2.1 Par swap NPV ≈ $0
    p_par = IRSPricer(curve, notional=10_000_000, fixed_rate=par,
                      direction='PAY', eff_date=EFF, mat_date=MAT, val_date=VD)
    r = p_par.price()
    test("Par swap NPV ≈ $0 (|NPV| < $10)", abs(r['npv'])<10, f"${r['npv']:,.2f}", "|NPV|<$10")

    # 2.2 Off-market sign: above par → NPV < 0
    p_hi = IRSPricer(curve, notional=10_000_000, fixed_rate=par+0.005,
                     direction='PAY', eff_date=EFF, mat_date=MAT, val_date=VD)
    npv_hi = p_hi.price()['npv']
    test("PAY FIXED +50bp above par → NPV < 0", npv_hi<0, f"${npv_hi:,.0f}", "< $0")

    # 2.3 Below par → NPV > 0
    p_lo = IRSPricer(curve, notional=10_000_000, fixed_rate=par-0.005,
                     direction='PAY', eff_date=EFF, mat_date=MAT, val_date=VD)
    npv_lo = p_lo.price()['npv']
    test("PAY FIXED -50bp below par → NPV > 0", npv_lo>0, f"${npv_lo:,.0f}", "> $0")

    # 2.4 Direction symmetry
    p_rcv = IRSPricer(curve, notional=10_000_000, fixed_rate=par+0.005,
                      direction='RECEIVE', eff_date=EFF, mat_date=MAT, val_date=VD)
    npv_rcv = p_rcv.price()['npv']
    test("PAY + RECEIVE NPV = $0 (mirror)", abs(npv_hi+npv_rcv)<1, f"${npv_hi+npv_rcv:,.2f}", "~$0")

    # 2.5 IR01 sign
    ir01 = r['ir01']
    test("PAY FIXED IR01 > 0", ir01>0, f"${ir01:,.2f}", "> $0")

    # 2.6 RECEIVE IR01 < 0
    p_rcv_par = IRSPricer(curve, notional=10_000_000, fixed_rate=par,
                          direction='RECEIVE', eff_date=EFF, mat_date=MAT, val_date=VD)
    ir01_rcv = p_rcv_par.price()['ir01']
    test("RECEIVE FIXED IR01 < 0", ir01_rcv<0, f"${ir01_rcv:,.2f}", "< $0")

    # 2.7 IR01 symmetry
    test("IR01 symmetry (|PAY+RECEIVE|<$1)", abs(ir01+ir01_rcv)<1, f"${ir01+ir01_rcv:,.2f}", "~$0")

    # 2.8 Notional linearity NPV
    p_2x = IRSPricer(curve, notional=20_000_000, fixed_rate=par+0.005,
                     direction='PAY', eff_date=EFF, mat_date=MAT, val_date=VD)
    ratio = p_2x.price()['npv']/npv_hi
    test("Notional linearity: 2× → 2× NPV", abs(ratio-2)<0.001, f"ratio={ratio:.4f}", "2.0")

    # 2.9 Notional linearity IR01
    ratio_ir01 = p_2x.price()['ir01']/ir01 if ir01 else 0
    test("Notional linearity: 2× → 2× IR01", abs(ratio_ir01-2)<0.05, f"ratio={ratio_ir01:.4f}", "2.0")

    # 2.10 IR01_DISC < IR01
    ir01_disc = r['ir01_disc']
    test("IR01_DISC < IR01", abs(ir01_disc)<abs(ir01), f"IR01={ir01:,.0f} DISC={ir01_disc:,.0f}", "|DISC|<|IR01|")

    # 2.11 IR01 magnitude: $3K-$6K for 5Y $10M
    test("IR01 magnitude $3K-$6K for 5Y $10M", 3000<=abs(ir01)<=6000, f"${ir01:,.2f}", "$3K-$6K")

    # 2.12 Par rate solver
    test("Par rate solver reasonable (2%-8%)", 0.02<=par<=0.08, f"{par*100:.4f}%", "2%-8%")

    return r, par

# ── 3. XVA ────────────────────────────────────────────────────────────────────

def test_xva(curve):
    from xva_engine import XVAEngine, DEFAULT_HW1F, DEFAULT_CP_CDS_CURVE, DEFAULT_OWN_CDS_CURVE, DEFAULT_FTP_CURVE
    from irs_pricer import IRSPricer
    section("3. XVA ENGINE")

    # Use a rate that's slightly off par so we have positive EE for PAY FIXED
    p0 = IRSPricer(curve, direction='PAY', eff_date='2026-04-14',
                   mat_date='2031-04-14', val_date='2026-04-10')
    par = p0.par_rate()

    def eng(**kw):
        defaults = dict(hw1f=DEFAULT_HW1F, curve=curve, notional=10_000_000,
                        maturity_y=5.0, fixed_rate=par, direction='PAY',
                        n_paths=2000, seed=42, lgd=0.40,
                        cp_cds_curve=DEFAULT_CP_CDS_CURVE,
                        own_cds_curve=DEFAULT_OWN_CDS_CURVE,
                        ftp_curve=DEFAULT_FTP_CURVE)
        defaults.update(kw)
        return XVAEngine(**defaults)

    res = eng().simulate()
    xva = res['xva']

    test("CVA < 0 (cost to us)", xva['cva']<0, f"${xva['cva']:,.0f}", "< $0")
    test("DVA > 0 (benefit to us)", xva['dva']>0, f"${xva['dva']:,.0f}", "> $0")
    test("FVA < 0 (funding cost)", xva['fva']<0, f"${xva['fva']:,.0f}", "< $0")
    test("KVA < 0 (capital cost)", xva['kva']<0, f"${xva['kva']:,.0f}", "< $0")
    test("MVA < 0 (margin cost)",  xva['mva']<0, f"${xva['mva']:,.0f}", "< $0")

    # Zero spreads → CVA=DVA=0
    r0 = eng(cp_cds_bp=0.0, own_cds_bp=0.0, cp_cds_curve=None, own_cds_curve=None).simulate()
    test("Zero CDS → CVA=$0", abs(r0['xva']['cva'])<1, f"${r0['xva']['cva']:,.2f}", "$0")
    test("Zero CDS → DVA=$0", abs(r0['xva']['dva'])<1, f"${r0['xva']['dva']:,.2f}", "$0")

    # LGD=0 → CVA=DVA=0
    rl = eng(lgd=0.0).simulate()
    test("LGD=0 → CVA=$0", abs(rl['xva']['cva'])<1, f"${rl['xva']['cva']:,.2f}", "$0")
    test("LGD=0 → DVA=$0", abs(rl['xva']['dva'])<1, f"${rl['xva']['dva']:,.2f}", "$0")

    # Direction flip
    rr = eng(direction='RECEIVE').simulate()
    test("RECEIVE: CVA < 0", rr['xva']['cva']<0, f"${rr['xva']['cva']:,.0f}", "< $0")
    test("RECEIVE: DVA > 0", rr['xva']['dva']>0, f"${rr['xva']['dva']:,.0f}", "> $0")

    # Maturity sensitivity: 2Y CVA ≈ 5-25% of 5Y
    r5 = eng(maturity_y=5.0, cp_cds_bp=85.0, own_cds_bp=42.0,
             cp_cds_curve=None, own_cds_curve=None).simulate()
    r2 = eng(maturity_y=2.0, cp_cds_bp=85.0, own_cds_bp=42.0,
             cp_cds_curve=None, own_cds_curve=None).simulate()
    cva5 = r5['xva']['cva']; cva2 = r2['xva']['cva']
    ratio = abs(cva2/cva5) if cva5 else 0
    test("2Y CVA is 5-25% of 5Y CVA", 0.05<=ratio<=0.25,
         f"ratio={ratio:.3f} (2Y=${cva2:,.0f} 5Y=${cva5:,.0f})", "5%-25%")

    # EE profile
    ee = res['ee']; times = res['times']
    peak_idx = max(range(1, len(ee)), key=lambda i: ee[i])  # skip t=0
    peak_t = times[peak_idx]
    test("EE peaks between 1Y and 4Y", 1.0<=peak_t<=4.0, f"peak at t={peak_t:.2f}Y", "1Y-4Y")
    test("EE ≥ 0 everywhere", all(e>=-1e-3 for e in ee), f"min={min(ee):,.0f}", "≥ 0")
    test("ENE ≤ 0 everywhere", all(e<=1e-3 for e in res['ene']), f"max={max(res['ene']):,.0f}", "≤ 0")
    test("All-in rate < par (XVA cost PAY FIXED)", res['all_in_rate_pct']<par*100,
         f"{res['all_in_rate_pct']:.4f}%", f"< {par*100:.4f}%")

    return res

# ── 4. Greeks ─────────────────────────────────────────────────────────────────

def test_greeks(curve, par):
    from irs_pricer import IRSPricer, bump_curve
    section("4. GREEKS & SENSITIVITIES")

    EFF = '2026-04-14'; MAT = '2031-04-14'; VD = '2026-04-10'
    p = IRSPricer(curve, notional=10_000_000, fixed_rate=par,
                  direction='PAY', eff_date=EFF, mat_date=MAT, val_date=VD)
    r = p.price()

    test("|Gamma| near zero for vanilla IRS (< $50)", abs(r['gamma'])<50,
         f"{r['gamma']:.4f}", "< $50")
    test("Theta non-zero", abs(r['theta'])>0, f"${r['theta']:,.2f}", "≠ 0")
    test("IR01 magnitude $3K-$6K", 3000<=abs(r['ir01'])<=6000,
         f"${r['ir01']:,.2f}", "$3K-$6K")
    test("|IR01_DISC| < |IR01|", abs(r['ir01_disc'])<abs(r['ir01']),
         f"DISC={r['ir01_disc']:,.0f}", f"< |{r['ir01']:,.0f}|")

    # Central difference IR01
    bd = bump_curve(curve, 1e-4); bu = bump_curve(curve, -1e-4)
    npv_up  = IRSPricer(bd, bd,  10_000_000, EFF, MAT, par, 'PAY', val_date=VD)._npv()
    npv_dn  = IRSPricer(bu, bu, 10_000_000, EFF, MAT, par, 'PAY', val_date=VD)._npv()
    central = (npv_up - npv_dn) / 2
    test("Central diff IR01 ≈ bump IR01 (|diff|<$10)", abs(central-r['ir01'])<10,
         f"central=${central:,.2f} bump=${r['ir01']:,.2f}", "|diff|<$10")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print(f"\n{'='*60}")
    print(f"  RIJEKA MODEL VALIDATION REPORT")
    print(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Platform:  Rijeka v0.4.2 | Sprint 6B")
    print(f"{'='*60}")

    try:
        from ois_bootstrap import build_sofr_curve
    except ImportError as e:
        print(f"\n  ERROR: {e}\n  Install: pip install numpy scipy python-dateutil")
        sys.exit(1)

    curve = build_sofr_curve()

    test_bootstrap(curve)
    result, par = test_irs(curve)
    test_xva(curve)
    test_greeks(curve, par)

    n_pass = sum(1 for r in RESULTS if r['status']=='PASS')
    n_fail = len(RESULTS) - n_pass

    print(f"\n{'='*60}")
    print(f"  SUMMARY: {n_pass}/{len(RESULTS)} PASSED  |  {n_fail} FAILED")
    print(f"{'='*60}")

    if n_fail > 0:
        print("\n  FAILED TESTS:")
        for r in RESULTS:
            if r['status']=='FAIL':
                print(f"    ✗ {r['name']}")
                print(f"      Expected: {r['expected']}")
                print(f"      Got:      {r['got']}")
    else:
        print("\n  ALL TESTS PASSED ✓")
        print("  Rijeka v0.4.2 — IRS + XVA model validation: APPROVED")
    print()
    return n_fail

if __name__ == '__main__':
    sys.exit(main())
