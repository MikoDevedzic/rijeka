"""
Rijeka Model Validation Package
XVA Engine — HW1F Monte Carlo + full waterfall
CVA/DVA/FVA/FBA/KVA/MVA

EE formula for vanilla IRS under HW1F:
  V(t,r) = notional * [1 - P(t,T_mat,r) - rate * annuity(t,r)]  for PAY FIXED
  P(t,T,r) = A(t,T) * exp(-B(t,T)*r)  [HW1F bond price]
  EE(t) = E[max(V(t), 0)]

CVA (corrected v0.4.2):
  h(t) = spread_bp(t)/10000
  Q(t) = exp(-h(t)*t)
  CVA = -LGD * sum_t EE(t) * (Q(t-1)-Q(t)) * DF(t) * WWR
"""

import math
import numpy as np
from typing import Optional, List
from ois_bootstrap import OISBootstrap, dcf_act365f


class HW1FModel:
    def __init__(self, a=0.0121, sigma_bp=29.99, theta=0.03595):
        self.a = a
        self.sigma_bp = sigma_bp
        self.sigma = sigma_bp / 10000.0
        self.theta = theta

    def B(self, t, T):
        if abs(self.a) < 1e-8: return T - t
        return (1.0 - math.exp(-self.a * (T - t))) / self.a

    def A_log(self, t, T, curve):
        """log A(t,T) in HW1F using initial curve."""
        if T <= t: return 0.0
        P0T = curve.df(T)
        P0t = curve.df(t) if t > 1e-6 else 1.0
        if P0t <= 0 or P0T <= 0: return 0.0
        B_val = self.B(t, T)
        # Instantaneous forward
        dt = 1e-4
        t2 = max(dt, t)
        f0t = -(math.log(curve.df(t2+dt)) - math.log(curve.df(max(dt, t2-dt)))) / (2*dt)
        # Variance term
        if self.a > 1e-8:
            var_term = (self.sigma**2 / (4.0*self.a) * B_val**2
                        * (1.0 - math.exp(-2.0*self.a*t))) if t > 0 else 0.0
        else:
            var_term = 0.0
        return math.log(P0T/P0t) + B_val*f0t - var_term

    def bond_price_vec(self, r_vec, t, T, curve):
        """P(t,T,r) as numpy array across paths."""
        if T <= t: return np.ones(len(r_vec))
        B_val = self.B(t, T)
        lnA   = self.A_log(t, T, curve)
        return np.exp(lnA - B_val * r_vec)

    def calibrate(self, basket, curve):
        from scipy.optimize import minimize
        def obj(params):
            a, s = max(0.001, params[0]), max(0.1, params[1])
            m = HW1FModel(a=a, sigma_bp=s)
            errs = []
            for inst in basket:
                Te, Tm = inst['T_exp'], inst['T_mat']
                tenor = Tm - Te
                V = s**2/1e8/a**2 * (tenor - 2/a*(1-math.exp(-a*tenor))
                    + 1/(2*a)*(1-math.exp(-2*a*tenor))) if a>0 else 0
                w = math.sqrt(max(0,V)/Te)*10000 if Te>0 else 0
                errs.append((w - inst['market_vol_bp'])**2)
            return sum(errs)
        res = minimize(obj, [self.a, self.sigma_bp], method='L-BFGS-B',
                       bounds=[(0.001,2.0),(0.1,200.0)])
        self.a, self.sigma_bp = res.x[0], res.x[1]
        self.sigma = self.sigma_bp/10000.0
        errs = []
        for inst in basket:
            Te, Tm = inst['T_exp'], inst['T_mat']
            tenor = Tm-Te
            V = self.sigma**2/self.a**2*(tenor-2/self.a*(1-math.exp(-self.a*tenor))
                +1/(2*self.a)*(1-math.exp(-2*self.a*tenor))) if self.a>0 else 0
            w = math.sqrt(max(0,V)/Te)*10000 if Te>0 else 0
            errs.append(w - inst['market_vol_bp'])
        rmse = math.sqrt(sum(e**2 for e in errs)/len(errs))
        return {'a':self.a,'sigma_bp':self.sigma_bp,'rmse_bp':rmse}


def interp_spread(curve_pts, flat_bp, t):
    if not curve_pts: return flat_bp
    pts = sorted(curve_pts, key=lambda x: x['t'])
    if t <= pts[0]['t']: return pts[0]['spread_bp']
    if t >= pts[-1]['t']: return pts[-1]['spread_bp']
    for i in range(len(pts)-1):
        t0,s0 = pts[i]['t'], pts[i]['spread_bp']
        t1,s1 = pts[i+1]['t'], pts[i+1]['spread_bp']
        if t0 <= t <= t1:
            return s0 + (s1-s0)*(t-t0)/(t1-t0)
    return flat_bp


class XVAEngine:
    """
    Full XVA waterfall via HW1F Monte Carlo.
    EE computed using exact HW1F bond prices along simulated paths.
    """
    def __init__(self, hw1f, curve, notional=10_000_000, maturity_y=5.0,
                 fixed_rate=0.03665, direction='PAY', n_paths=2000, seed=42,
                 cp_cds_bp=85.0, own_cds_bp=42.0, lgd=0.40, wwr=1.0,
                 cp_cds_curve=None, own_cds_curve=None,
                 ftp_bp=55.0, fba_ratio=0.55, ftp_curve=None,
                 hurdle_rate=0.12, capital_model='sa_ccr', simm_im_m=0.85):
        self.hw   = hw1f; self.curve = curve
        self.n    = notional; self.T  = maturity_y
        self.rate = fixed_rate
        self.pay  = direction.upper() == 'PAY'
        self.paths_n = n_paths; self.seed = seed
        self.cp_cds_bp  = cp_cds_bp;  self.own_cds_bp = own_cds_bp
        self.lgd = lgd; self.wwr = wwr
        self.cp_cds_curve = cp_cds_curve; self.own_cds_curve = own_cds_curve
        self.ftp_bp = ftp_bp; self.fba_ratio = fba_ratio; self.ftp_curve = ftp_curve
        self.hurdle = hurdle_rate; self.simm_im_m = simm_im_m

    def _swap_value(self, r_vec, t, curve):
        """
        V(t,r) for PAY FIXED IRS under HW1F.
        V = notional * [float_value - fixed_annuity * rate]
        float_value = 1 - P(t, T_mat, r)  [floating leg approximation]
        fixed_annuity = sum_i frac_i * P(t, T_i, r)
        """
        rem = self.T - t
        if rem <= 1e-6:
            return np.zeros(len(r_vec))

        # Annual payment times from t to T
        pay_times = []
        tp = t
        while tp < self.T - 1e-6:
            tp = min(tp + 1.0, self.T)
            pay_times.append(tp)

        # Annuity: sum of dcf * P(t, T_i, r)
        annuity = np.zeros(len(r_vec))
        prev = t
        for Ti in pay_times:
            frac = Ti - prev  # simplified ACT/365F annual = 1.0
            annuity += frac * self.hw.bond_price_vec(r_vec, t, Ti, curve)
            prev = Ti

        # Float leg value: 1 - P(t, T_mat)
        P_mat = self.hw.bond_price_vec(r_vec, t, self.T, curve)
        float_val = 1.0 - P_mat

        # Swap value (RECEIVE FIXED perspective)
        V = self.n * (self.rate * annuity - float_val)

        # For PAY FIXED: negate (PAY fixed = negative fixed + positive float)
        if self.pay:
            V = -V

        return V

    def simulate(self):
        rng = np.random.default_rng(self.seed)
        dt = 1.0/12.0
        n_steps = int(self.T / dt)
        times = np.linspace(0, self.T, n_steps+1)

        # Simulate HW1F short rate paths
        a = self.hw.a; sigma = self.hw.sigma; theta = self.hw.theta
        r0 = -math.log(self.curve.df(dt)) / dt if dt > 0 else 0.035

        r = np.full(self.paths_n, r0)
        ee  = np.zeros(n_steps+1)
        ene = np.zeros(n_steps+1)
        pfe = np.zeros(n_steps+1)

        # Compute EE at each time step
        for i, t in enumerate(times):
            if t > 0:
                dW = rng.normal(0, math.sqrt(dt), self.paths_n)
                r  = r + (theta - a*r)*dt + sigma*dW

            V = self._swap_value(r, t, self.curve)
            ee[i]  = float(np.mean(np.maximum(V, 0)))
            ene[i] = float(np.mean(np.minimum(V, 0)))
            pfe[i] = float(np.percentile(np.maximum(V, 0), 95))

        dfs = np.array([self.curve.df(t) for t in times])

        # Convention: EE at t=0 is 0 (par trade, current NPV=0)
        ee[0] = 0.0; ene[0] = 0.0; pfe[0] = 0.0

        # XVA waterfall
        cva = dva = fva = fba = kva = 0.0
        for i in range(1, len(times)):
            t_prev = times[i-1]; t_curr = times[i]; dt_i = t_curr-t_prev
            df_i   = dfs[i]

            h_cp  = interp_spread(self.cp_cds_curve,  self.cp_cds_bp,  t_curr)/10000
            h_own = interp_spread(self.own_cds_curve, self.own_cds_bp, t_curr)/10000
            h_cp0 = interp_spread(self.cp_cds_curve,  self.cp_cds_bp,  t_prev)/10000
            h_ow0 = interp_spread(self.own_cds_curve, self.own_cds_bp, t_prev)/10000

            qcp_p  = math.exp(-h_cp0 * t_prev);  qcp_c  = math.exp(-h_cp  * t_curr)
            qown_p = math.exp(-h_ow0 * t_prev);  qown_c = math.exp(-h_own * t_curr)

            cva += -self.lgd * ee[i]       * (qcp_p  - qcp_c)  * df_i * self.wwr
            dva += +self.lgd * abs(ene[i]) * (qown_p - qown_c) * df_i

            ftp_t  = interp_spread(self.ftp_curve, self.ftp_bp, t_curr)/10000
            fba_r  = ftp_t * self.fba_ratio
            fva   += -ee[i]        * ftp_t  * dt_i * df_i
            fba   += +abs(ene[i]) * fba_r  * dt_i * df_i

            ead = ee[i] * 1.4 * 1.5
            kva += -ead * 0.08 * self.hurdle * dt_i * df_i

        mva = -self.simm_im_m * 1_000_000 * self.ftp_bp/10000 * self.T/2

        all_in = cva + dva + fva + fba + kva + mva
        dv01   = self.n * self.T / 10000
        all_in_bp   = all_in/dv01 if dv01 else 0
        all_in_rate = self.rate*100 + all_in_bp/100

        return {
            'npv': 0.0,
            'xva': {'cva':cva,'dva':dva,'fva':fva,'fba':fba,'kva':kva,'mva':mva,'all_in':all_in},
            'ee': ee.tolist(), 'ene': ene.tolist(), 'pfe_95': pfe.tolist(),
            'times': times.tolist(), 'n_paths': self.paths_n,
            'params': {'a':self.hw.a, 'sigma_bp':self.hw.sigma_bp, 'theta':self.hw.theta},
            'all_in_rate_pct': all_in_rate, 'all_in_bp': all_in_bp,
        }


DEFAULT_HW1F = HW1FModel(a=0.0121, sigma_bp=29.99, theta=0.03595)

DEFAULT_CP_CDS_CURVE = [
    {'t':1,'spread_bp':72},{'t':2,'spread_bp':78},{'t':3,'spread_bp':83},
    {'t':5,'spread_bp':91},{'t':7,'spread_bp':97},{'t':10,'spread_bp':105},
]
DEFAULT_OWN_CDS_CURVE = [
    {'t':1,'spread_bp':38},{'t':2,'spread_bp':41},{'t':3,'spread_bp':44},
    {'t':5,'spread_bp':48},{'t':7,'spread_bp':51},{'t':10,'spread_bp':55},
]
DEFAULT_FTP_CURVE = [
    {'t':1,'spread_bp':42},{'t':2,'spread_bp':46},{'t':3,'spread_bp':50},
    {'t':5,'spread_bp':55},{'t':7,'spread_bp':58},{'t':10,'spread_bp':62},
]

SWAPTION_BASKET_5Y = [
    {'T_exp':1.0,'T_mat':6.0,'market_vol_bp':95.2,'label':'1Y×5Y'},
    {'T_exp':2.0,'T_mat':7.0,'market_vol_bp':102.1,'label':'2Y×5Y'},
    {'T_exp':3.0,'T_mat':8.0,'market_vol_bp':105.8,'label':'3Y×5Y'},
    {'T_exp':5.0,'T_mat':10.0,'market_vol_bp':108.3,'label':'5Y×5Y'},
    {'T_exp':7.0,'T_mat':12.0,'market_vol_bp':103.7,'label':'7Y×5Y'},
    {'T_exp':10.0,'T_mat':15.0,'market_vol_bp':96.4,'label':'10Y×5Y'},
]


if __name__ == '__main__':
    from ois_bootstrap import build_sofr_curve
    from irs_pricer import IRSPricer
    curve = build_sofr_curve()

    # Get par rate
    p = IRSPricer(curve, direction='PAY', eff_date='2026-04-14',
                  mat_date='2031-04-14', val_date='2026-04-10')
    par = p.par_rate()

    engine = XVAEngine(DEFAULT_HW1F, curve, notional=10_000_000,
                       maturity_y=5.0, fixed_rate=par, direction='PAY',
                       n_paths=2000, seed=42,
                       cp_cds_curve=DEFAULT_CP_CDS_CURVE,
                       own_cds_curve=DEFAULT_OWN_CDS_CURVE,
                       ftp_curve=DEFAULT_FTP_CURVE)
    res = engine.simulate()
    xva = res['xva']
    print(f"Par rate: {par*100:.4f}%  |  Paths: {res['n_paths']}")
    print(f"Peak EE: ${max(res['ee']):,.0f}  |  EE peak at t={res['times'][res['ee'].index(max(res['ee']))]:.1f}Y")
    print(f"CVA: ${xva['cva']:,.0f}  DVA: ${xva['dva']:,.0f}  FVA: ${xva['fva']:,.0f}")
    print(f"KVA: ${xva['kva']:,.0f}  MVA: ${xva['mva']:,.0f}  ALL-IN: ${xva['all_in']:,.0f}")
